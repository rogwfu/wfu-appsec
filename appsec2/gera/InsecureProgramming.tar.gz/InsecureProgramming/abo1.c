/* abo1.c                                       *
 * specially crafted to feed your brain by gera */

/* Dumb example to let you get introduced...    */

int main(int argv,char **argc) {
	char buf[256];

	strcpy(buf,argc[1]);
}
