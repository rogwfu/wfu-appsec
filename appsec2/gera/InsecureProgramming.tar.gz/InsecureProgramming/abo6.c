/* abo6.c                                                   *
 * specially crafted to feed your brain by gera@core-sdi.com */

/* return to me my love                                     */

int main(int argv,char **argc) {
	char *pbuf=malloc(strlen(argc[2])+1);
	char buf[256];

	strcpy(buf,argc[1]);
	strcpy(pbuf,argc[2]);
	while(1);
}
