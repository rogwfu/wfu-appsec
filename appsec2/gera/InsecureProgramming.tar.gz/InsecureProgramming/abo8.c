/* abo8.c                                                    *
 * specially crafted to feed your brain by gera@core-sdi.com */

/* spot the difference */



char buf[256];

int main(int argv,char **argc) {
	strcpy(buf,argc[1]);
}
