/* <A HRef=e4.c>e4.c</a>                                                      *
 * specially crafted to feed your brain by gera@core-sdi.com */

/* %what the hell?                                           */

char buf[256];

int main(int argv,char **argc) {
	strcpy(buf,argc[1]);
	printf("live at 100%!");
	while(1);
}
